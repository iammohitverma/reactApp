import React from 'react';

function NotFound() {
  return (
    <>
      NotFound
    </>
  );
}

export default NotFound;
