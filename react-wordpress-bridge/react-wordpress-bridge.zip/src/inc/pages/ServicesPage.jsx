import React from 'react';
import GlobalComp from '../global/globalComponent';

function Services({pageName}) {
  return (
    <>
      <GlobalComp PageName={pageName}/>
    </>
  );
}

export default Services;
