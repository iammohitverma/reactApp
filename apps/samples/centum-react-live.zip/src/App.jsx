import "./App.css";
import { Routes, Route } from "react-router-dom";

import { Header } from "./Header";
import { Footer } from "./Footer";

import { Home } from "./Pages/Home";
import { About } from "./Pages/About";
import { Error } from "./Pages/Error";

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="*" element={<Error />} />
      </Routes>
      <Footer />
    </>
  );
}
export default App;
