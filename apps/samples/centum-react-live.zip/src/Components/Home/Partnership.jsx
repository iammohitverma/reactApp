export const Partnership = () => {
  return (
    <>
      <section className="partnership sec-pt-80 sec-pb-80 text-center">
        <div className="container">
          <div className="row">
            <div className="col-md-10 mx-auto">
              <div className="heading white">
                <h1>
                  In partnership with reputable banks delivering flexible
                  mortgage options.
                </h1>
              </div>
              <div className="text-wrap">
                <p>
                  As a leading mortgage broker in Hamilton (and surrounding
                  areas), my partnerships with reputable banks allow me to
                  deliver an extensive array of flexible mortgage options and
                  services, granting you convenient access to the resources
                  essential for securing the ideal mortgage and achieving your
                  homeownership goals
                </p>
              </div>
              <ul className="banks">
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/td-bank.png"
                      alt="td-bank"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/manulife.png"
                      alt="manulife"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/scotiabank.png"
                      alt="scotiabank"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/cwb-bank.png"
                      alt="cwb-bank.png"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/first-national.png"
                      alt="first-national"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/first-ontario.png"
                      alt="first-ontario"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/haventree-bank.png"
                      alt="haventree-bank"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/meridian.png"
                      alt="meridian"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/rmg.png"
                      alt="rmg.png"
                    />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                  >
                    <img
                      src="https://techmind.co.in/react_websites/centum/img/equitable-bank.png"
                      alt="equitable-bank"
                    />
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
