export const QuestionAnswer = () => {
  return (
    <>
      <section className="mortage-ques-ans sec-pt-80 sec-pb-80">
        <div className="container">
          <div className="heading text-center">
            <h1>Mortgage Question and Answers</h1>
          </div>
          <div className="text-wrap">
            <p>
              As a top mortgage broker in Hamilton, | invite you to peruse the
              questions and answers below, which tackle the most frequently
              asked mortgage questions. This informative resource has been
              created to offer you valuable insights and professional guidance,
              assisting you in navigating the home financing process and making
              the best decisions for your unique circumstances.
            </p>
          </div>
          <div className="ques-ans-wrap">
            <div className="row gx-10">
              <div className="col-md-6">
                <div className="box">
                  <ul>
                    <li>
                      <h5 className="ques">
                        Lorem ipsum dolor sit amet,ipiscing elit. Sed
                        ullamcorper, neque suscipit congue semper, elit tellus
                        interdum diam?
                      </h5>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Sed ullamcorper, neque suscipit congue semper, elit
                        tellus interdum diam, id mattis erat lorem a risus. Ut
                        mollis sit amet urna at posuere. Nunc turpis. magna,
                        fringilla at ornare quis, convallis dignissim nibh.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Lorem ipsum dolor sit amet,
                      </p>
                      <p>
                        consectetur adipiscing elit. Sed ullamcorper, neque
                        suscipit congue semper, elt tellus interdum diam, id
                        mattis erat lorem a risus. Ut mollis sit amet urna at
                        posuere. Nunc turpis magna, fringilla at omare quis,
                        convallis dignissim nibh. Lorem ipsum dolor sit amet,
                        consectetur adipiscing elit
                      </p>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elt.
                        Sed ullamcorper, neque suscipit congue semper, elit
                        tellus interdum diam, id mattis erat lorem a risus. Ut
                        mollis sit amet urna at posuere. Nunc turpis. magna,
                        fringilla at ornare quis, convallis dignissim nibh.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      </p>
                    </li>
                    <li>
                      <h5 className="ques">
                        Lorem ipsum dolor sit amet,ipiscing elit. Sed
                        ullamcorper, neque suscipit congue semper, elit tellus
                        interdum diam?
                      </h5>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Sed ullamcorper, neque suscipit congue semper, elit
                        tellus interdum diam, id mattis erat lorem a risus. Ut
                        mollis sit amet urna at posuere. Nunc turpis. magna,
                        fringilla at omare quis, convallis dignissim nibh. Lorem
                        ipsum dolor s
                      </p>
                    </li>
                    <li>
                      <h5 className="ques">
                        Lorem ipsum dolor sit amet,ipiscing elit. Sed
                        ullamcorper, neque suscipit congue semper, elit tellus
                        interdum diam?
                      </h5>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Sed ullamcorper, neque suscipit congue semper, elit
                        tellus interdum diam, id mattis erat lorem a risus. Ut
                        mollis sit amet urna at posuere. Nunc turpis. magna,
                        fringilla at ornare quis, convallis dignissim nibh.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Sed ullamcorper, neque suscipit congue semper.
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-md-6">
                <div className="box">
                  <ul>
                    <li>
                      <h5 className="ques">
                        Lorem ipsum dolor sit amet,ipiscing elit. Sed
                        ullamcorper, neque suscipit congue semper, elit tellus
                        interdum diam?
                      </h5>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing lit.
                        Sed ullamcorper, neque suscipit congue semper, lit
                        tellus interdum diam, id mats erat lorem a risus. Ut
                        mollis sit amet ura at posuere. Nunc turpis magna,
                        fringilla at ornare quis, convallis dignissim nibh.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Lorem ipsum dolor sit amet,
                      </p>
                      <a
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                        }}
                        download=""
                        className="download-btn"
                      >
                        <img
                          src="https://techmind.co.in/react_websites/centum/img/download-checklist.png"
                          alt="download-checklist"
                        />
                      </a>
                    </li>
                    <li>
                      <h5 className="ques">
                        Lorem ipsum dolor sit amet,ipiscing elit, Sed
                        ullamcorper, neque suscipit congue semper, elit tellus
                        interdum diam?
                      </h5>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Sed ullamcorper, neque suscipit congue semper, lit
                        tellus interdum diam, id mattis rat orem a risus.
                        Utmolls sit amet urna at posure.
                      </p>
                    </li>
                    <li>
                      <h5 className="ques">
                        Lorem ipsum dolor sit amet,ipiscing elit. Sed
                        ullamcorper, neque suscipit congue semper, elit tellus
                        interdum diam?
                      </h5>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing eli.
                        Sed ullamcorper, neque suscipit congue semper, elit
                        tellus interdum diam, id mattis erat lorem a risus.
                        Utmolis sit amet ura at posuere. Sed ullamcorper, neque
                        suscipit congue semper, eit tellus interdum diam, id
                        mattis erat lorem a risus.
                      </p>
                      <a
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                        }}
                        className="youtube-btn"
                      >
                        <img
                          src="https://techmind.co.in/react_websites/centum/img/youtube-thumb.png"
                          alt="youtube-thumb"
                        />
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="apply-mortage text-center">
            <h3>
              As your trusted mortage broker to the Hamilton area,
              <br />
              let me help you secure your dream home today.
            </h3>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
              }}
              className="centum-btn"
            >
              Apply For A Mortgage Now
            </a>
          </div>
        </div>
      </section>
    </>
  );
};
