export const TrustedMortage = () => {
  return (
    <>
      <section className="trusted-mortage sec-pt-80 sec-pb-80">
        <div className="container">
          <div className="heading text-center">
            <h1>Your trusted mortage broker to the Hamilton area!</h1>
          </div>
          <div className="row">
            <div className="col-lg-9">
              <div className="text-wrap">
                <p>
                  As a leading mortgage broker in Hamilton, my dedication to
                  providing exceptional service and support to homebuyers in the
                  area has earned me a strong reputation for reliability and
                  expertise. My in-depth understanding of the Hamilton market,
                  along with a vast network of lenders, allows me to effectively
                  assist clients in navigating the intricate world of home
                  financing. As your mortgage broker in Hamilton, | am committed
                  to transparency, integrity, and professionalism, prioritizing
                  your best interests while delivering custom-tailored mortgage
                  options designed to align with your specific needs and
                  financial objectives.
                </p>
                <p>
                  Whether you&apos;re a first-time homebuyer or an experienced
                  investor, my extensive knowledge as a mortgage broker in
                  Hamilton ensures that you receive efficient and seamless
                  financing solutions. By offering unparalleled customer
                  service, | take the time to comprehend your individual
                  circumstances and work diligently to secure the most
                  competitive mortgage rates on your behalf. Trust in me, your
                  mortgage broker in Hamilton, to guide and support you
                  throughout the home buying process, empowering you to make
                  well-informed decisions as you invest in your future in this
                  vibrant community of Hamilton!
                </p>
              </div>
            </div>
            <div className="col-lg-3">
              <div className="registered-member">
                <h4>
                  A Proud and <br />
                  Registered Member of:
                </h4>
                <ul>
                  <li>
                    <a
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                    >
                      <img
                        src="https://techmind.co.in/react_websites/centum/img/cmba.png"
                        alt="cmba"
                      />
                    </a>
                  </li>
                  <li>
                    <a
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                    >
                      <img
                        src="https://techmind.co.in/react_websites/centum/img/fsra.png"
                        alt="fsra"
                      />
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
