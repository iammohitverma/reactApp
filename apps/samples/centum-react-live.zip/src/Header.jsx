export const Header = () => {
  return (
    <>
      <header>
        <div className="container">
          <div className="inner">
            <a
              href="https://techmind.co.in/react_websites/centum/"
              className="logo"
            >
              <img
                src="https://techmind.co.in/react_websites/centum/img/logo.webp"
                alt="CENTUM Logo"
              />
            </a>
          </div>
        </div>
      </header>
    </>
  );
};
