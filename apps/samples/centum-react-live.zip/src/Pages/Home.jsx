import { Banner } from "../Components/Home/Banner";
import { TrustedMortage } from "../Components/Home/TrustedMortage";
import { Partnership } from "../Components/Home/Partnership";
import { QuestionAnswer } from "../Components/Home/QuestionAnswer";
import { Testimonials } from "../Components/Home/Testimonials";
import { Services } from "../Components/Home/Services";

export const Home = () => {
  return (
    <>
      <Banner />
      <TrustedMortage />
      <Partnership />
      <QuestionAnswer />
      <Testimonials />
      <Services />
    </>
  );
};
