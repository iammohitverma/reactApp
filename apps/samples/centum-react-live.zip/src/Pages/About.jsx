import { Banner } from "../Components/Home/Banner";

export const About = () => {
  return (
    <>
      <Banner />
    </>
  );
};
