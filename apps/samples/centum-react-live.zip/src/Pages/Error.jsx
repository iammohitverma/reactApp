import { Banner } from "../Components/Home/Banner";

export const Error = () => {
  return (
    <>
      <h1>Page Not Fount</h1>
    </>
  );
};
