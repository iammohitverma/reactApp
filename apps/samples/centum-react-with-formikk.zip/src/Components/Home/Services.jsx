export const Services = () => {
  return (
    <>
      <section className="services sec-pt-80 sec-pb-80 text-center">
        <div className="container">
          <div className="heading">
            <h1>
              Not only am | a leading mortgage broker to the Hamilton area, |
              also offer these additional services:
            </h1>
          </div>
          <div className="text-wrap">
            <p>
              Committed to your financial success, | offer personalized and
              approachable financial services, tailored to your unique needs and
              circumstances. | am here to help you achieve your long-term
              financial aspirations.
            </p>
          </div>
          <div className="services-wrap">
            <div className="row">
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img
                      src="/img/services-1.png"
                      alt="Mortgage Pre-Approval"
                    />
                  </i>
                  <h3>Mortgage Pre-Approval</h3>
                  <p>
                    Mortgage pre-approval gives you a head start in the home
                    buying process, providing you with the tools and knowledge
                    to secure your perfect home.
                  </p>
                </div>
              </div>
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img
                      src="/img/services-2.png"
                      alt="First Time Home Buyers"
                    />
                  </i>
                  <h3>First Time Home Buyers</h3>
                  <p>
                    I'm here to help first time home: buyers achieve their
                    homeownership dreams by simplifying the complex home buying
                    process.
                  </p>
                </div>
              </div>
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img src="/img/services-3.png" alt="Mortgage Refinancing" />
                  </i>
                  <h3>Mortgage Refinancing</h3>
                  <p>
                    I'm committed to helping you achieve financial stability by
                    providing expert guidance on valuable mortgage refinancing
                    strategies.
                  </p>
                </div>
              </div>
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img
                      src="/img/services-4.png"
                      alt="Alternative Mortgages"
                    />
                  </i>
                  <h3>Alternative Mortgages</h3>
                  <p>
                    Alternative mortgages offer flexible financing options
                    tailored to your needs and ideal for those who do not
                    qualify for traditional mortgages.
                  </p>
                </div>
              </div>
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img src="/img/services-5.png" alt="Private Mortgages" />
                  </i>
                  <h3>Private Mortgages</h3>
                  <p>
                    As a private mortgage expert, | provide borrowers with
                    tailored financing solutions that cater to their unique
                    financial circumstances.
                  </p>
                </div>
              </div>
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img
                      src="/img/services-6.png"
                      alt="Vacation Home Mortgages"
                    />
                  </i>
                  <h3>Vacation Home Mortgages</h3>
                  <p>
                    I provide buyers with customized financing solutions for
                    vacation homes, ensuring they can achieve their dream of
                    owning a second property.
                  </p>
                </div>
              </div>
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img src="/img/services-8.png" alt="Reverse Mortgages" />
                  </i>
                  <h3>Reverse Mortgages</h3>
                  <p>
                    As a reverse mortgage expert, | help homeowners achieve
                    financial freedom by leveraging the equity in their homes
                    without selling their property.
                  </p>
                </div>
              </div>
              <div className="col-md-6 col-lg-3">
                <div className="service-box">
                  <i className="icon">
                    <img
                      src="/img/services-8.png"
                      alt="Alternative Mortgages"
                    />
                  </i>
                  <h3>Alternative Mortgages</h3>
                  <p>
                    Alternative mortgages offer flexible financing options
                    tailored to your needs and ideal for those who do not
                    qualify for traditional mortgages.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="apply-mortage text-center">
            <h3>
              As your trusted mortage broker to the Hamilton area,
              <br />
              let me help you secure your dream home today.
            </h3>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
              }}
              className="centum-btn"
            >
              Apply For A Mortgage Now
            </a>
          </div>
        </div>
      </section>
    </>
  );
};
