export const Header = () => {
  return (
    <>
      <header>
        <div className="container">
          <div className="inner">
            <a href="/" className="logo">
              <img src="/img/logo.webp" alt="CENTUM Logo" />
            </a>
          </div>
        </div>
      </header>
    </>
  );
};
