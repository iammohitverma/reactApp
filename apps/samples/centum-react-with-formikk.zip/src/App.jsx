import "./App.css";
import { Routes, Route } from "react-router-dom";

import { Header } from "./Header";
import { Footer } from "./Footer";

import { Home } from "./Pages/Home";
function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route exact path="/" element={<Home />} />
      </Routes>
      <Footer />
    </>
  );
}
export default App;
