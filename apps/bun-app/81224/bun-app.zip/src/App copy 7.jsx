import { UseReducerComp } from "./UseReducerComp";
import "./App.css";

function App() {
  return <UseReducerComp />;
}

export default App;
