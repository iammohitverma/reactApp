import { TodoApp } from "./TodoApp";
import "./App.css"

function App() {
  return (
    <>
      <TodoApp />
    </>
  );
}

export default App;
