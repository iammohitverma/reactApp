import ContextApi from "./ContextApi";
import "./App.css";

function App() {
  return (
    <>
      <ContextApi />
    </>
  );
}

export default App;
