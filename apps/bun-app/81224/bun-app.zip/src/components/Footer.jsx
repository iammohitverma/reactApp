export const Footer = () => {
  return (
    <footer>
      <div className="container">
        <p>I am footer</p>
      </div>
    </footer>
  );
};
