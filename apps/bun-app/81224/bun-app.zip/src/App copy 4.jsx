import { FormWithUseRef } from "./FormWithUseRef";
import "./App.css";

function App() {
  return (
    <>
      <FormWithUseRef />
    </>
  );
}

export default App;
