import { Form } from "./Form";
import "./App.css"

function App() {
  return (
    <>
      <Form />
    </>
  );
}

export default App;
