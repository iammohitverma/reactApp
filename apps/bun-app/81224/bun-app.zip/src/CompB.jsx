import { CompC } from "./CompC";
export const CompB = () => {
  return (
    <div>
      <h1>CompB</h1>
      <CompC />
    </div>
  );
};
