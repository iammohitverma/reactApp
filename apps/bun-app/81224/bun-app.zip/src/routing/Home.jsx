export const Home = () => {
  return (
    <div className="py-5">
      <div className="container">
        <h1>Welcome to the Home Page</h1>
      </div>
    </div>
  );
};
