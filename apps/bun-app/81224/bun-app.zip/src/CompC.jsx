export const CompC = () => {
  return (
    <div>
      <h1>CompC</h1>
    </div>
  );
};
