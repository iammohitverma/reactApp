import { FormWithUseId } from "./FormWithUseId";
import "./App.css";

function App() {
  return (
    <>
      <FormWithUseId />
    </>
  );
}

export default App;
