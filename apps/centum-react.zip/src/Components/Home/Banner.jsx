export const Banner = () => {
  return (
    <>
      <section className="hero">
        <div className="shape"></div>
        <div className="container">
          <div className="hero-content">
            <div className="content">
              <div className="text-wrap">
                <h1>
                  Your leading mortgage <br />
                  broker in Hamilton and <br />
                  surrounding areas!
                </h1>
                <p>
                  I am your leading mortgage broker in Hamilton, offering
                  unparalleled expertise and personalized solutions for every
                  homebuyer&apos;s unique - needs. Unlock the doors to your
                  dream home with a fast and easy mortgage!
                </p>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                  }}
                  className="centum-btn"
                >
                  Apply For A Mortgage Now
                </a>
                <div className="broker">
                  <h2>Sherri Vigna</h2>
                  <p>
                    Mortgage Broker <br />
                    Licence #M15002024
                  </p>
                </div>
              </div>
              <div className="mobile img-wrap">
                <img src="/img/hero-girl.png" alt="hero-girl" />
              </div>
            </div>
          </div>
        </div>
        <div className="desktop img-wrap">
          <img src="/img/hero-girl.png" alt="hero-girl" />
        </div>
      </section>
    </>
  );
};
