// import Swiper core and required modules
import { Pagination, A11y } from "swiper/modules";

// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

export const Testimonials = () => {
  return (
    <>
      <section className="testimonials sec-pt-80 sec-pb-80 text-center">
        <div className="container">
          <div className="row">
            <div className="col-md-10 mx-auto">
              <div className="heading white">
                <h1>See what others have to say about working with me...</h1>
              </div>
              <div className="testimonials-wrap">
                <Swiper
                  modules={[Pagination, A11y]}
                  spaceBetween={50}
                  slidesPerView={1}
                  pagination={{ clickable: true }}
                  onSwiper={(swiper) => console.log(swiper)}
                >
                  <SwiperSlide>
                    <div className="testimonial">
                      <div className="text-wrap">
                        <h5>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit. Sed ullamcorper, neque suscipit congue semper,
                          elit tellus interdum diam, id mattis erat lorem a
                          risus. Ut mollis sit amet urna at posuere. Nunc turpis
                          magna, fringilla at ornare quis, convallis dignissim
                          nibh.
                        </h5>
                        <p className="testimonial-name">
                          - John S, Hamilton residenet -
                        </p>
                      </div>
                    </div>
                  </SwiperSlide>
                  <SwiperSlide>
                    <div className="testimonial">
                      <div className="text-wrap">
                        <h5>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit. Sed ullamcorper, neque suscipit congue semper,
                          elit tellus interdum diam, id mattis erat lorem a
                          risus. Ut mollis sit amet urna at posuere. Nunc turpis
                          magna, fringilla at ornare quis, convallis dignissim
                          nibh.
                        </h5>
                        <p className="testimonial-name">
                          - John S, Hamilton residenet -
                        </p>
                      </div>
                    </div>
                  </SwiperSlide>
                  <SwiperSlide>
                    <div className="testimonial">
                      <div className="text-wrap">
                        <h5>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit. Sed ullamcorper, neque suscipit congue semper,
                          elit tellus interdum diam, id mattis erat lorem a
                          risus. Ut mollis sit amet urna at posuere. Nunc turpis
                          magna, fringilla at ornare quis, convallis dignissim
                          nibh.
                        </h5>
                        <p className="testimonial-name">
                          - John S, Hamilton residenet -
                        </p>
                      </div>
                    </div>
                  </SwiperSlide>
                </Swiper>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
