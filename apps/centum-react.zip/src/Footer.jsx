export const Footer = () => {
  return (
    <>
      <footer>
        <div className="top">
          <div className="container">
            <div className="row">
              <div className="col-md-12 col-lg-4">
                <div className="footer-widget about">
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                    }}
                    className="logo"
                  >
                    <img src="/img/logo.webp" alt="CENTUM Logo" />
                  </a>
                  <p>
                    Our network spans over 200 offices and 2200+ mortgage
                    professionals across Canada to help you with all your
                    mortgage needs
                  </p>
                  <div className="follow-us">
                    <p>
                      Follow me on social media today:
                      <a
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                        }}
                      >
                        <img src="/img/facebook.png" alt="facebook" />
                      </a>
                      <a
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                        }}
                      >
                        <img src="/img/instagram.png" alt="instagram" />
                      </a>
                    </p>
                  </div>
                </div>
              </div>

              <div className="col-md-6 col-lg-4">
                <div className="footer-widget address">
                  <ul>
                    <li>
                      <div className="office">
                        <i className="icon">
                          <img src="/img/location.png" alt="location" />
                        </i>
                        <div className="text">
                          <div className="left">
                            <h4>Head Office:</h4>
                            <p>
                              282 Geneve St, St <br />
                              Catharines, ON
                              <br />
                              L2N 2E8
                            </p>
                          </div>
                          <div className="right">
                            <h4>Satellite Offices:</h4>
                            <p>
                              -Fort Erie <br />
                              -Font Hill <br />
                              -Niagara Falls
                            </p>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <i className="icon">
                        <img src="/img/mobile.png" alt="mobile" />
                      </i>
                      <div className="text">
                        <h4>
                          Phone:<a href="tel: (888) 888-8888">(888) 888-8888</a>
                        </h4>
                        <h4>
                          Toll Free:
                          <a href="tel: (888) 888-8888">(888) 888-8888</a>
                        </h4>
                      </div>
                    </li>
                    <li>
                      <i className="icon">
                        <img src="/img/email.png" alt="email" />
                      </i>
                      <div className="text">
                        <h4>
                          Email:
                          <a href="mailto:info@centum.ca">info@centum.ca</a>
                        </h4>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="footer-widget signup">
                  <div className="member-of">
                    <p>Member of:</p>
                    <a
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                    >
                      <img src="/img/footer-cmba.png" alt="cmba" />
                    </a>
                    <a
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                    >
                      <img src="/img/footer-fsra.png" alt="fsra" />
                    </a>
                  </div>
                  <p>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                    Provident pariatur, hic, ipsa a sequi earum, consectetur
                    error neque
                  </p>
                  <div className="signup-wrap">
                    <form>
                      <div className="input-wrap">
                        <input
                          type="email"
                          name="email"
                          placeholder="Email Address"
                        />
                        <input
                          type="text"
                          name="postalCode"
                          placeholder="Postal Code"
                        />
                      </div>
                      <div className="submit-wrap">
                        <button type="submit">
                          SIGN UP
                          <i className="icon">
                            <img src="/img/arrow-right.png" alt="arrow-right" />
                          </i>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="copyright">
          <div className="container">
            <ul className="term-links">
              <li>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                  }}
                >
                  Terms and Conditions
                </a>
              </li>
              <li>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                  }}
                >
                  Sitemap
                </a>
              </li>
              <li>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                  }}
                >
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </>
  );
};
