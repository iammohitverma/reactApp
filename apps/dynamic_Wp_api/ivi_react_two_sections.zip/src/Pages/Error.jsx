export const Error = () => {
  return (
    <>
      <h1>Error</h1>
    </>
  );
};
