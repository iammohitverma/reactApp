import React from 'react';
// import GlobalComp from '../global/globalComponent';

function Register() {
    return <><a href="javascript:void(0)" className="g-btn g-gradient-btn"> Register</a></>;
}

export default Register;
