import React from 'react';
// import GlobalComp from '../global/globalComponent';

function NotFound() {
  return (
    <>
      Event Page
    </>
  );
}

export default NotFound;
