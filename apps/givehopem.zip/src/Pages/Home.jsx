import { Play, BulbOutline, CashOutline, PeopleCircle } from "react-ionicons";

// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";

export const Home = () => {
  return (
    <>
      <div className="block-31">
        <div className="loop-block-31">
          <div
            className="block-30 block-30-sm item"
            style={{
              backgroundImage:
                "url('https://techmind.co.in/react_websites/support-hub/images/bg_1.jpg')",
            }}
            data-stellar-background-ratio="0.5"
          >
            <div className="container">
              <div className="row align-items-center justify-content-center text-center">
                <div className="col-md-7">
                  <h2 className="heading mb-5">
                    Free Website Template for Charity Websites.
                  </h2>
                  <p style={{ display: "inline-block" }}>
                    <a
                      href="https://vimeo.com/channels/staffpicks/93951774"
                      data-fancybox
                      className="ftco-play-video d-flex"
                      target="_blank"
                    >
                      <span className="play-icon-wrap align-self-center mr-4">
                        <Play color={"#f7ca44"} height="35px" width="35px" />
                      </span>
                      <span className="align-self-center">Watch Video</span>
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section section-counter">
        <div className="container">
          <div className="row">
            <div className="col-md-6 pr-5">
              <div className="block-48">
                <span className="block-48-text-1">Served Over</span>
                <div
                  className="block-48-counter ftco-number"
                  data-number="1321901"
                >
                  1,321,901
                </div>
                <span className="block-48-text-1 mb-4 d-block">
                  Children in 150 Countries
                </span>
                <p className="mb-0">
                  <a
                    href="javascript:void(0)"
                    className="btn btn-white px-3 py-2"
                  >
                    View Our Program
                  </a>
                </p>
              </div>
            </div>
            <div className="col-md-6 welcome-text">
              <h2 className="display-4 mb-3">Who Are We?</h2>
              <p className="lead">
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts. Separated
                they live in Bookmarksgrove right at the coast of the Semantics,
                a large language ocean.
              </p>
              <p className="mb-4">
                A small river named Duden flows by their place and supplies it
                with the necessary regelialia.
              </p>
              <p className="mb-0">
                <a
                  href="javascript:void(0)"
                  className="btn btn-primary px-3 py-2"
                >
                  Learn More
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section border-top">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <div className="media block-6">
                <div className="icon">
                  <BulbOutline color={"#f7ca44"} height="35px" width="35px" />
                </div>
                <div className="media-body">
                  <h3 className="heading">Our Mission</h3>
                  <p>
                    A small river named Duden flows by their place and supplies
                    it with the necessary regelialia.
                  </p>
                  <p>
                    <a href="javascript:void(0)" className="link-underline">
                      Learn More
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="media block-6">
                <div className="icon">
                  <CashOutline color={"#f7ca44"} height="35px" width="35px" />
                </div>
                <div className="media-body">
                  <h3 className="heading">Make Donations</h3>
                  <p>
                    A small river named Duden flows by their place and supplies
                    it with the necessary regelialia.
                  </p>
                  <p>
                    <a href="javascript:void(0)" className="link-underline">
                      Learn More
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="media block-6">
                <div className="icon">
                  <PeopleCircle color={"#f7ca44"} height="35px" width="35px" />
                </div>
                <div className="media-body">
                  <h3 className="heading">We Need Volunteers</h3>
                  <p>
                    A small river named Duden flows by their place and supplies
                    it with the necessary regelialia.
                  </p>
                  <p>
                    <a href="javascript:void(0)" className="link-underline">
                      Learn More
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section fund-raisers bg-light">
        <div className="container">
          <div className="row mb-3 justify-content-center">
            <div className="col-md-8 text-center">
              <h2>Latest Fundraisers</h2>
              <p className="lead">
                Some quick example text to build on the card title and make up
                the bulk of the cards content.
              </p>
            </div>
          </div>
        </div>

        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12 block-11">
              <div className="nonloop-block-11 ">
                <Swiper
                  spaceBetween={50}
                  slidesPerView={3}
                  onSlideChange={() => console.log("slide change")}
                  onSwiper={(swiper) => console.log(swiper)}
                  centeredSlides={true}
                >
                  <SwiperSlide>
                    <div className="card fundraise-item">
                      <a href="javascript:void(0)">
                        <img
                          className="card-img-top"
                          src="https://techmind.co.in/react_websites/support-hub/images/img_1.jpg"
                          alt="Image placeholder"
                        />
                      </a>
                      <div className="card-body">
                        <h3 className="card-title">
                          <a href="javascript:void(0)">
                            Water Is Life. Clean Water In Urban Area
                          </a>
                        </h3>
                        <p className="card-text">
                          Some quick example text to build on the card title and
                          make up the bulk of the card's content.
                        </p>
                        <span className="donation-time mb-3 d-block">
                          Last donation 1w ago
                        </span>
                        <div className="progress custom-progress-success">
                          <div
                            className="progress-bar bg-primary"
                            role="progressbar"
                          ></div>
                        </div>
                        <span className="fund-raised d-block">
                          $12,000 raised of $30,000
                        </span>
                      </div>
                    </div>
                  </SwiperSlide>
                  <SwiperSlide>
                    <div className="card fundraise-item">
                      <a href="javascript:void(0)">
                        <img
                          className="card-img-top"
                          src="https://techmind.co.in/react_websites/support-hub/images/img_7.jpg"
                          alt="Image placeholder"
                        />
                      </a>
                      <div className="card-body">
                        <h3 className="card-title">
                          <a href="javascript:void(0)">
                            Need Shelter for Children in Africa
                          </a>
                        </h3>
                        <p className="card-text">
                          Some quick example text to build on the card title and
                          make up the bulk of the card's content.
                        </p>
                        <span className="donation-time mb-3 d-block">
                          Last donation 1w ago
                        </span>
                        <div className="progress custom-progress-success">
                          <div
                            className="progress-bar bg-primary"
                            role="progressbar"
                          ></div>
                        </div>
                        <span className="fund-raised d-block">
                          $12,000 raised of $30,000
                        </span>
                      </div>
                    </div>
                  </SwiperSlide>
                  <SwiperSlide>
                    <div className="card fundraise-item">
                      <a href="javascript:void(0)">
                        <img
                          className="card-img-top"
                          src="https://techmind.co.in/react_websites/support-hub/images/img_3.jpg"
                          alt="Image placeholder"
                        />
                      </a>
                      <div className="card-body">
                        <h3 className="card-title">
                          <a href="javascript:void(0)">
                            Children Needs Education
                          </a>
                        </h3>
                        <p className="card-text">
                          Some quick example text to build on the card title and
                          make up the bulk of the card's content.
                        </p>
                        <span className="donation-time mb-3 d-block">
                          Last donation 1w ago
                        </span>
                        <div className="progress custom-progress-success">
                          <div
                            className="progress-bar bg-primary"
                            role="progressbar"
                          ></div>
                        </div>
                        <span className="fund-raised d-block">
                          $12,000 raised of $30,000
                        </span>
                      </div>
                    </div>
                  </SwiperSlide>
                  <SwiperSlide>
                    <div className="card fundraise-item">
                      <a href="javascript:void(0)">
                        <img
                          className="card-img-top"
                          src="https://techmind.co.in/react_websites/support-hub/images/img_6.jpg"
                          alt="Image placeholder"
                        />
                      </a>
                      <div className="card-body">
                        <h3 className="card-title">
                          <a href="javascript:void(0)">Voluteer </a>
                        </h3>
                        <p className="card-text">
                          Some quick example text to build on the card title and
                          make up the bulk of the card's content.
                        </p>
                        <span className="donation-time mb-3 d-block">
                          Last donation 1w ago
                        </span>
                        <div className="progress custom-progress-success">
                          <div
                            className="progress-bar bg-primary"
                            role="progressbar"
                          ></div>
                        </div>
                        <span className="fund-raised d-block">
                          $12,000 raised of $30,000
                        </span>
                      </div>
                    </div>
                  </SwiperSlide>
                </Swiper>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section fund-raisers">
        <div className="container">
          <div className="row mb-3 justify-content-center">
            <div className="col-md-8 text-center">
              <h2>Latest Donations</h2>
              <p className="lead">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
            </div>
          </div>

          <div className="row">
            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_1.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Jorge Smith</h2>
                  <span className="time d-block mb-3">Donated Just now</span>
                  <p>
                    Donated <span className="text-success">$252</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Water Is Life. Clean Water In Urban Area
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_2.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Christine Charles</h2>
                  <span className="time d-block mb-3">Donated 1 hour ago</span>
                  <p>
                    Donated <span className="text-success">$400</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Children Needs Education
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_3.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Albert Sluyter</h2>
                  <span className="time d-block mb-3">Donated 4 hours ago</span>
                  <p>
                    Donated <span className="text-success">$1,200</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Need Shelter for Children in Africa
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_4.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Andrew Holloway</h2>
                  <span className="time d-block mb-3">Donated 9 hours ago</span>
                  <p>
                    Donated <span className="text-success">$100</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Water Is Life. Clean Water In Urban Area
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="featured-section overlay-color-2"
        style={{
          backgroundImage:
            "url('https://techmind.co.in/react_websites/support-hub/images/bg_3.jpg')",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <img
                src="https://techmind.co.in/react_websites/support-hub/images/bg_3.jpg"
                alt="Image placeholder"
                className="img-fluid"
              />
            </div>

            <div className="col-md-6 pl-md-5">
              <span className="featured-text d-block mb-3">
                Success Stories
              </span>
              <h2>
                Water Is Life. We Successfuly Provide Clean Water in South East
                Asia
              </h2>
              <p className="mb-3">
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts.
              </p>
              <span className="fund-raised d-block mb-5">
                We have raised $100,000
              </span>

              <p>
                <a
                  href="javascript:void(0)"
                  className="btn btn-success btn-hover-white py-3 px-5"
                >
                  Read The Full Story
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section bg-light">
        <div className="container">
          <div className="row mb-5">
            <div className="col-md-12">
              <h2>Latest News</h2>
            </div>
          </div>

          <div className="row">
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_4.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Be A Volunteer Today</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_5.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">
                    You May Save The Life of A Child
                  </a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_6.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Children That Needs Care</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="featured-section overlay-color-2"
        style={{
          backgroundImage:
            "url('https://techmind.co.in/react_websites/support-hub/images/bg_2.jpg')",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-md-6 mb-5 mb-md-0">
              <img
                src="https://techmind.co.in/react_websites/support-hub/images/bg_2.jpg"
                alt="Image placeholder"
                className="img-fluid"
              />
            </div>

            <div className="col-md-6 pl-md-5">
              <div className="form-volunteer">
                <h2>Be A Volunteer Today</h2>
                <form action="#" method="post">
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control py-2"
                      id="name"
                      placeholder="Enter your name"
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control py-2"
                      id="email"
                      placeholder="Enter your email"
                    />
                  </div>
                  <div className="form-group">
                    <textarea
                      name="v_message"
                      id=""
                      cols="30"
                      rows="3"
                      className="form-control py-2"
                      placeholder="Write your message"
                    ></textarea>
                  </div>
                  <div className="form-group">
                    <input
                      type="submit"
                      className="btn btn-white px-5 py-2"
                      value="Send"
                    />
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
