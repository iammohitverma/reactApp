export const Blog = () => {
  return (
    <>
      <div className="block-31">
        <div className="owl-carousel loop-block-31 owl-loaded">
          <div className="owl-stage-outer">
            <div className="owl-stage">
              <div className="owl-item active">
                <div
                  className="block-30 block-30-sm item"
                  style={{
                    backgroundImage:
                      'url("https://techmind.co.in/react_websites/support-hub/images/bg_1.jpg")',
                  }}
                  data-stellar-background-ratio="0.5"
                >
                  <div className="container">
                    <div className="row align-items-center justify-content-center text-center">
                      <div className="col-md-7">
                        <h2 className="heading">Our Blog</h2>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section bg-light">
        <div className="container">
          <div className="row">
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_4.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Be A Volunteer Today</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_5.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">
                    You May Save The Life of A Child
                  </a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_6.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Children That Needs Care</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>

            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_4.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Be A Volunteer Today</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_5.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">
                    You May Save The Life of A Child
                  </a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_6.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Children That Needs Care</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>

            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_4.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Be A Volunteer Today</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_5.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">
                    You May Save The Life of A Child
                  </a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
            <div className="col-12 col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0">
              <div className="post-entry">
                <a href="javascript:void(0)" className="mb-3 img-wrap">
                  <img
                    src="https://techmind.co.in/react_websites/support-hub/images/img_6.jpg"
                    alt="Image placeholder"
                    className="img-fluid"
                  />
                </a>
                <h3>
                  <a href="javascript:void(0)">Children That Needs Care</a>
                </h3>
                <span className="date mb-4 d-block text-muted">
                  July 26, 2018
                </span>
                <p>
                  Far far away, behind the word mountains, far from the
                  countries Vokalia and Consonantia.
                </p>
                <p>
                  <a href="javascript:void(0)" className="link-underline">
                    Read More
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
