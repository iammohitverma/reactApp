export const Contact = () => {
  return (
    <>
      <div className="block-31">
        <div className=" loop-block-31 owl-loaded">
          <div className="owl-stage-outer">
            <div className="owl-stage">
              <div className="owl-item active">
                <div
                  className="block-30 block-30-sm item"
                  style={{
                    backgroundImage:
                      'url("https://techmind.co.in/react_websites/support-hub/images/bg_2.jpg")',
                  }}
                  data-stellar-background-ratio="0.5"
                >
                  <div className="container">
                    <div className="row align-items-center justify-content-center">
                      <div className="col-md-7 text-center">
                        <h2 className="heading">Get In Touch</h2>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="owl-nav disabled">
            <div className="owl-prev disabled">
              <span className="ion-md-arrow-back"></span>
            </div>
            <div className="owl-next disabled">
              <span className="ion-md-arrow-forward"></span>
            </div>
          </div>
          <div className="owl-dots disabled">
            <div className="owl-dot active">
              <span></span>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section">
        <div className="container">
          <div className="row block-9">
            <div className="col-md-12 pr-md-5">
              <form action="#">
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control px-3 py-3"
                    placeholder="Your Name"
                  />
                </div>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control px-3 py-3"
                    placeholder="Your Email"
                  />
                </div>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control px-3 py-3"
                    placeholder="Subject"
                  />
                </div>
                <div className="form-group">
                  <textarea
                    name=""
                    id=""
                    cols="30"
                    rows="7"
                    className="form-control px-3 py-3"
                    placeholder="Message"
                  ></textarea>
                </div>
                <div className="form-group">
                  <input
                    type="submit"
                    value="Send Message"
                    className="btn btn-primary py-3 px-5"
                  />
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
