export const Donate = () => {
  return (
    <>
      <div className="block-31">
        <div className="owl-carousel loop-block-31 owl-loaded">
          <div className="owl-stage-outer">
            <div className="owl-stage">
              <div className="owl-item active">
                <div
                  className="block-30 block-30-sm item"
                  style={{
                    backgroundImage:
                      'url("https://techmind.co.in/react_websites/support-hub/images/bg_1.jpg")',
                  }}
                  data-stellar-background-ratio="0.5"
                >
                  <div className="container">
                    <div className="row align-items-center justify-content-center text-center">
                      <div className="col-md-7">
                        <h2 className="heading">
                          Better To Give Than To Receive
                        </h2>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="site-section fund-raisers">
        <div className="container">
          <div className="row mb-3 justify-content-center">
            <div className="col-md-8 text-center">
              <h2>Latest Donations</h2>
              <p className="lead">
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </p>
            </div>
          </div>

          <div className="row">
            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_1.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Jorge Smith</h2>
                  <span className="time d-block mb-3">Donated Just now</span>
                  <p>
                    Donated <span className="text-success">$252</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Water Is Life. Clean Water In Urban Area
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_2.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Christine Charles</h2>
                  <span className="time d-block mb-3">Donated 1 hour ago</span>
                  <p>
                    Donated <span className="text-success">$400</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Children Needs Education
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_3.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Albert Sluyter</h2>
                  <span className="time d-block mb-3">Donated 4 hours ago</span>
                  <p>
                    Donated <span className="text-success">$1,200</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Need Shelter for Children in Africa
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_4.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Andrew Holloway</h2>
                  <span className="time d-block mb-3">Donated 9 hours ago</span>
                  <p>
                    Donated <span className="text-success">$100</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Water Is Life. Clean Water In Urban Area
                    </a>
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_1.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Jorge Smith</h2>
                  <span className="time d-block mb-3">Donated Just now</span>
                  <p>
                    Donated <span className="text-success">$252</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Water Is Life. Clean Water In Urban Area
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_2.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Christine Charles</h2>
                  <span className="time d-block mb-3">Donated 1 hour ago</span>
                  <p>
                    Donated <span className="text-success">$400</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Children Needs Education
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_3.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Albert Sluyter</h2>
                  <span className="time d-block mb-3">Donated 4 hours ago</span>
                  <p>
                    Donated <span className="text-success">$1,200</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Need Shelter for Children in Africa
                    </a>
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-6 col-lg-3 mb-5">
              <div className="person-donate text-center">
                <img
                  src="https://techmind.co.in/react_websites/support-hub/images/person_4.jpg"
                  alt="Image placeholder"
                  className="img-fluid"
                />
                <div className="donate-info">
                  <h2>Andrew Holloway</h2>
                  <span className="time d-block mb-3">Donated 9 hours ago</span>
                  <p>
                    Donated <span className="text-success">$100</span> <br />
                    <em>for</em>
                    <a
                      href="javascript:void(0)"
                      className="link-underline fundraise-item"
                    >
                      Water Is Life. Clean Water In Urban Area
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="featured-section overlay-color-2"
        style={{
          backgroundImage:
            "url('https://techmind.co.in/react_websites/support-hub/images/bg_3.jpg')",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <img
                src="https://techmind.co.in/react_websites/support-hub/images/bg_3.jpg"
                alt="Image placeholder"
                className="img-fluid"
              />
            </div>

            <div className="col-md-6 pl-md-5">
              <span className="featured-text d-block mb-3">
                Success Stories
              </span>
              <h2>
                Water Is Life. We Successfuly Provide Clean Water in South East
                Asia
              </h2>
              <p className="mb-3">
                Far far away, behind the word mountains, far from the countries
                Vokalia and Consonantia, there live the blind texts.
              </p>
              <span className="fund-raised d-block mb-5">
                We have raised $100,000
              </span>

              <p>
                <a
                  href="javascript:void(0)"
                  className="btn btn-success btn-hover-white py-3 px-5"
                >
                  Read The Full Story
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
