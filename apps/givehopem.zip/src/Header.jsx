import { useState } from "react";
import { NavLink } from "react-router-dom";
export const Header = () => {
  const [isToggled, setToggle] = useState(false);
  const toggleMenu = (e) => {
    console.log(e);
    setToggle(!isToggled);
  };
  return (
    <nav
      className="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div className="container">
        <a className="navbar-brand" href="/react_websites/support-hub/">
          Support Hub
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
          onClick={toggleMenu}
        >
          <span className="oi oi-menu"></span> Menu
        </button>

        <div
          className={`collapse navbar-collapse ${isToggled ? "show" : "hide"}`}
          id="ftco-nav"
        >
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <NavLink
                to="/react_websites/support-hub/"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Home
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/react_websites/support-hub/about"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                About
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/react_websites/support-hub/howitworks"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                How It Works
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/react_websites/support-hub/donate"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Donate
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/react_websites/support-hub/gallery"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Gallery
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/react_websites/support-hub/blog"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Blog
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                to="/react_websites/support-hub/contact"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Contact
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};
