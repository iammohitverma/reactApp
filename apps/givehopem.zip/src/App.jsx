import { Routes, Route } from "react-router-dom";

import { Header } from "./Header.jsx";
import { Home } from "./Pages/Home.jsx";
import { About } from "./Pages/About.jsx";
import { Donate } from "./Pages/Donate.jsx";
import { HowItWorks } from "./Pages/HowItWorks.jsx";
import { Gallery } from "./Pages/Gallery.jsx";
import { Blog } from "./Pages/Blog.jsx";
import { Contact } from "./Pages/Contact.jsx";
import { Footer } from "./Footer.jsx";
// import About from "./About";
// import Contact from "./Contact";
// import Error from "./Error";

export const App = () => {
  return (
    <>
      <Header />
      <Routes>
        {/* <Route index element={<Home pageTitle="Home" />} /> */}
        <Route
          path="/react_websites/support-hub/"
          element={<Home pageTitle="Home" />}
        />
        <Route path="/react_websites/support-hub/about" element={<About />} />
        <Route path="/react_websites/support-hub/donate" element={<Donate />} />
        <Route
          path="/react_websites/support-hub/howitworks"
          element={<HowItWorks />}
        />
        <Route
          path="/react_websites/support-hub/gallery"
          element={<Gallery />}
        />
        <Route path="/react_websites/support-hub/blog" element={<Blog />} />
        <Route
          path="/react_websites/support-hub/contact"
          element={<Contact />}
        />
      </Routes>
      <Footer />
    </>
  );
};
